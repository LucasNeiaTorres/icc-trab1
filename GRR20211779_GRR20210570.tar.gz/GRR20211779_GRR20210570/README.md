# EP-01 - Representação Numérica e Erros
## Leonardo Becker de Oliveira - GRR20211779
## Lucas Néia Torres - GRR20210570

### Limitações
As possíveis limitações apresentadas pelo programa se dão justamente pelo limite de representação da máquina, em que valores exponencias extremos, ou valores específicos ( valores reservados e denormalizados ),apresentam resultados como Infinity ( overflow e underflow ) e NaN.
